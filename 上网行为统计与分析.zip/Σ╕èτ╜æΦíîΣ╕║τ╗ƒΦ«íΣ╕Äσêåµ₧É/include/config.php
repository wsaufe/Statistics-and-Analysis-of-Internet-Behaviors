<?php
define("dbhost","prohost");
define("dbuser","prouser");
define("dbpass","propass");
define("dbname","prodbname");
$conn = mysqli_connect(dbhost,dbuser,dbpass,dbname);
?>